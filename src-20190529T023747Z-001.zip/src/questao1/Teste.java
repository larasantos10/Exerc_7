/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao1;

/**
 *
 * @author larasantos10
 */
public class Teste {
    public void main(String[] args){
        Pessoa p = new Pessoa ("Lara", "Rua Bahia", "5879-0000");        
        p.mostrar();
        f.obterSaldo();
        
        Fornecedor f = new Fornecedor (300, 500,"Adidas", "Rua 0", "2013-8082");
        f.mostrar();        
        
        Empregado e = new Empregado ("01", 999, 0.055, "Estacio", "Lugar Nenhum", "(00) 0000-0000");
        e.mostrar();
        e.calcularSalario();
               
        
    }
}
